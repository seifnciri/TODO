import Todo from "../models/todoModel.js"

// @desc    Get all todos for a user
// @route   GET /api/todos
// @access  Private
const getTodos = async (req, res) => {
  try {
    const todos = await Todo.find({ user: req.user._id })
    res.json(todos)
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message })
  }
}

// @desc    Create a new todo
// @route   POST /api/todos
// @access  Private
const createTodo = async (req, res) => {
  const { title, description } = req.body

  try {
    const todo = await Todo.create({
      user: req.user._id,
      title,
      description,
    })

    res.status(201).json(todo)
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message })
  }
}

// @desc    Get todo by ID
// @route   GET /api/todos/:id
// @access  Private
const getTodoById = async (req, res) => {
  try {
    const todo = await Todo.findById(req.params.id)

    if (todo) {
      // Check if the todo belongs to the logged in user
      if (todo.user.toString() !== req.user._id.toString()) {
        return res.status(401).json({ message: "Not authorized" })
      }
      res.json(todo)
    } else {
      res.status(404).json({ message: "Todo not found" })
    }
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message })
  }
}

// @desc    Update a todo
// @route   PUT /api/todos/:id
// @access  Private
const updateTodo = async (req, res) => {
  const { title, description, completed } = req.body

  try {
    const todo = await Todo.findById(req.params.id)

    if (todo) {
      // Check if the todo belongs to the logged in user
      if (todo.user.toString() !== req.user._id.toString()) {
        return res.status(401).json({ message: "Not authorized" })
      }

      todo.title = title || todo.title
      todo.description = description || todo.description

      // Only update completed if it's provided
      if (completed !== undefined) {
        todo.completed = completed
      }

      const updatedTodo = await todo.save()
      res.json(updatedTodo)
    } else {
      res.status(404).json({ message: "Todo not found" })
    }
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message })
  }
}

// @desc    Delete a todo
// @route   DELETE /api/todos/:id
// @access  Private
const deleteTodo = async (req, res) => {
  try {
    const todo = await Todo.findById(req.params.id)

    if (todo) {
      // Check if the todo belongs to the logged in user
      if (todo.user.toString() !== req.user._id.toString()) {
        return res.status(401).json({ message: "Not authorized" })
      }

      await Todo.deleteOne({ _id: req.params.id })
      res.json({ message: "Todo removed" })
    } else {
      res.status(404).json({ message: "Todo not found" })
    }
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message })
  }
}

export { getTodos, createTodo, getTodoById, updateTodo, deleteTodo }
