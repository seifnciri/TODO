"use client"

import { createContext, useState, useContext, useEffect } from "react"
import { useAuth } from "./AuthContext"

const TodoContext = createContext()

export const useTodos = () => {
  return useContext(TodoContext)
}

export const TodoProvider = ({ children }) => {
  const { user } = useAuth()
  const [todos, setTodos] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [selectedTodo, setSelectedTodo] = useState(null)

  // Fetch todos when user changes
  useEffect(() => {
    if (user) {
      fetchTodos()
    } else {
      setTodos([])
      setLoading(false)
    }
  }, [user])

  // Fetch all todos
  const fetchTodos = async () => {
    if (!user) return

    setLoading(true)
    try {
      const response = await fetch("http://localhost:5000/api/todos", {
        headers: {
          Authorization: `Bearer ${user.token}`,
        },
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.message || "Failed to fetch todos")
      }

      setTodos(data)
      setError(null)
    } catch (error) {
      setError(error.message)
    } finally {
      setLoading(false)
    }
  }

  // Create a new todo
  const createTodo = async (todoData) => {
    if (!user) return

    try {
      const response = await fetch("http://localhost:5000/api/todos", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${user.token}`,
        },
        body: JSON.stringify(todoData),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.message || "Failed to create todo")
      }

      setTodos([...todos, data])
      return data
    } catch (error) {
      setError(error.message)
      throw error
    }
  }

  // Update a todo
  const updateTodo = async (id, todoData) => {
    if (!user) return

    try {
      const response = await fetch(`http://localhost:5000/api/todos/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${user.token}`,
        },
        body: JSON.stringify(todoData),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.message || "Failed to update todo")
      }

      setTodos(todos.map((todo) => (todo._id === id ? data : todo)))

      // Update selected todo if it's the one being updated
      if (selectedTodo && selectedTodo._id === id) {
        setSelectedTodo(data)
      }

      return data
    } catch (error) {
      setError(error.message)
      throw error
    }
  }

  // Delete a todo
  const deleteTodo = async (id) => {
    if (!user) return

    try {
      const response = await fetch(`http://localhost:5000/api/todos/${id}`, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${user.token}`,
        },
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.message || "Failed to delete todo")
      }

      setTodos(todos.filter((todo) => todo._id !== id))

      // Clear selected todo if it's the one being deleted
      if (selectedTodo && selectedTodo._id === id) {
        setSelectedTodo(null)
      }

      return true
    } catch (error) {
      setError(error.message)
      throw error
    }
  }

  // Toggle todo completion status
  const toggleTodoStatus = async (id, completed) => {
    return updateTodo(id, { completed })
  }

  // Select a todo to view details
  const selectTodo = (todo) => {
    setSelectedTodo(todo)
  }

  const value = {
    todos,
    loading,
    error,
    selectedTodo,
    fetchTodos,
    createTodo,
    updateTodo,
    deleteTodo,
    toggleTodoStatus,
    selectTodo,
  }

  return <TodoContext.Provider value={value}>{children}</TodoContext.Provider>
}
