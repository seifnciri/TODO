"use client"

import { Routes, Route, Navigate } from "react-router-dom"
import { useAuth } from "./context/AuthContext"
import LoginPage from "./pages/LoginPage"
import RegisterPage from "./pages/RegisterPage"
import TodoDashboard from "./pages/TodoDashboard"

function App() {
  const { user } = useAuth()

  return (
    <Routes>
      <Route path="/" element={user ? <TodoDashboard /> : <Navigate to="/login" />} />
      <Route path="/login" element={!user ? <LoginPage /> : <Navigate to="/" />} />
      <Route path="/register" element={!user ? <RegisterPage /> : <Navigate to="/" />} />
    </Routes>
  )
}

export default App
