"use client"

import { useState } from "react"
import { useAuth } from "../context/AuthContext"
import { TodoProvider } from "../context/TodoContext"
import Header from "../components/Header"
import TodoList from "../components/TodoList"
import TodoDetail from "../components/TodoDetail"
import TodoForm from "../components/TodoForm"
import "../styles/dashboard.css"

const TodoDashboard = () => {
  const { user } = useAuth()
  const [showAddForm, setShowAddForm] = useState(false)

  if (!user) {
    return <div>Please login to view your todos</div>
  }

  return (
    <TodoProvider>
      <div className="dashboard-container">
        <Header />
        <div className="dashboard-content">
          <div className="todo-sections">
            <TodoList title="Active Tasks" filter={false} />
            <TodoDetail />
            <TodoList title="Completed Tasks" filter={true} />
          </div>
          {showAddForm && (
            <div className="modal-overlay">
              <div className="modal-content">
                <TodoForm onClose={() => setShowAddForm(false)} />
              </div>
            </div>
          )}
          <button className="add-todo-btn" onClick={() => setShowAddForm(true)}>
            + Add Task
          </button>
        </div>
      </div>
    </TodoProvider>
  )
}

export default TodoDashboard
