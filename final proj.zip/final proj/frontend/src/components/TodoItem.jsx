"use client"

import { useTodos } from "../context/TodoContext"
import "../styles/todo-item.css"

const TodoItem = ({ todo }) => {
  const { toggleTodoStatus, deleteTodo, selectTodo, selectedTodo } = useTodos()

  const handleToggle = (e) => {
    e.stopPropagation()
    toggleTodoStatus(todo._id, !todo.completed)
  }

  const handleDelete = (e) => {
    e.stopPropagation()
    deleteTodo(todo._id)
  }

  const handleSelect = () => {
    selectTodo(todo)
  }

  const isSelected = selectedTodo && selectedTodo._id === todo._id

  return (
    <li className={`todo-item ${isSelected ? "selected" : ""}`} onClick={handleSelect}>
      <div className="todo-item-content">
        <input type="checkbox" checked={todo.completed} onChange={handleToggle} onClick={(e) => e.stopPropagation()} />
        <div className="todo-text">
          <h3>{todo.title}</h3>
        </div>
      </div>
      <button className="delete-btn" onClick={handleDelete}>
        ×
      </button>
    </li>
  )
}

export default TodoItem
