"use client"

import { useState } from "react"
import { useTodos } from "../context/TodoContext"
import TodoForm from "./TodoForm"
import "../styles/todo-detail.css"

const TodoDetail = () => {
  const { selectedTodo, selectTodo } = useTodos()
  const [editing, setEditing] = useState(false)

  if (!selectedTodo) {
    return (
      <div className="todo-detail empty-detail">
        <p>Select a task to view details</p>
      </div>
    )
  }

  if (editing) {
    return (
      <div className="todo-detail">
        <TodoForm todo={selectedTodo} onClose={() => setEditing(false)} />
      </div>
    )
  }

  return (
    <div className="todo-detail">
      <div className="detail-header">
        <h2>Task Details</h2>
        <div className="detail-actions">
          <button className="btn btn-edit" onClick={() => setEditing(true)}>
            Edit
          </button>
          <button className="btn btn-close" onClick={() => selectTodo(null)}>
            Close
          </button>
        </div>
      </div>
      <div className="detail-content">
        <h3>{selectedTodo.title}</h3>
        <p className="detail-description">{selectedTodo.description}</p>
        <div className="detail-meta">
          <p>
            <strong>Status:</strong> {selectedTodo.completed ? "Completed" : "Active"}
          </p>
          <p>
            <strong>Created:</strong> {new Date(selectedTodo.createdAt).toLocaleString()}
          </p>
          {selectedTodo.updatedAt !== selectedTodo.createdAt && (
            <p>
              <strong>Last Updated:</strong> {new Date(selectedTodo.updatedAt).toLocaleString()}
            </p>
          )}
        </div>
      </div>
    </div>
  )
}

export default TodoDetail
