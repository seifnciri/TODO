"use client"

import { useState, useEffect } from "react"
import { useTodos } from "../context/TodoContext"
import "../styles/todo-form.css"

const TodoForm = ({ todo, onClose }) => {
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)
  const { createTodo, updateTodo } = useTodos()

  // If todo is provided, we're in edit mode
  const isEditMode = !!todo

  useEffect(() => {
    if (isEditMode) {
      setTitle(todo.title)
      setDescription(todo.description)
    }
  }, [isEditMode, todo])

  const handleSubmit = async (e) => {
    e.preventDefault()

    if (!title || !description) {
      setError("Please fill in all fields")
      return
    }

    try {
      setError("")
      setLoading(true)

      if (isEditMode) {
        await updateTodo(todo._id, { title, description })
      } else {
        await createTodo({ title, description })
      }

      onClose()
    } catch (error) {
      setError(error.message || "Failed to save todo")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="todo-form">
      <h2>{isEditMode ? "Edit Task" : "Add New Task"}</h2>
      {error && <div className="error-message">{error}</div>}
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="title">Title</label>
          <input type="text" id="title" value={title} onChange={(e) => setTitle(e.target.value)} required />
        </div>
        <div className="form-group">
          <label htmlFor="description">Description</label>
          <textarea
            id="description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            required
            rows={5}
          ></textarea>
        </div>
        <div className="form-actions">
          <button type="button" className="btn btn-cancel" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="btn btn-primary" disabled={loading}>
            {loading ? "Saving..." : isEditMode ? "Update" : "Add"}
          </button>
        </div>
      </form>
    </div>
  )
}

export default TodoForm
