"use client"

import { useAuth } from "../context/AuthContext"
import "../styles/header.css"

const Header = () => {
  const { user, logout } = useAuth()

  return (
    <header className="header">
      <div className="logo">Todo App</div>
      <div className="user-info">
        <span>Welcome, {user.name}</span>
        <button onClick={logout} className="btn btn-logout">
          Logout
        </button>
      </div>
    </header>
  )
}

export default Header
