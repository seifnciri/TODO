import { useTodos } from "../context/TodoContext"
import TodoItem from "./TodoItem"
import "../styles/todo-list.css"

const TodoList = ({ title, filter }) => {
  const { todos, loading, error } = useTodos()

  // Filter todos based on completion status
  const filteredTodos = todos.filter((todo) => todo.completed === filter)

  if (loading) {
    return <div className="loading">Loading tasks...</div>
  }

  if (error) {
    return <div className="error">Error: {error}</div>
  }

  return (
    <div className="todo-list">
      <h2>
        {title} ({filteredTodos.length})
      </h2>
      {filteredTodos.length === 0 ? (
        <p className="empty-list">No tasks found</p>
      ) : (
        <ul>
          {filteredTodos.map((todo) => (
            <TodoItem key={todo._id} todo={todo} />
          ))}
        </ul>
      )}
    </div>
  )
}

export default TodoList
